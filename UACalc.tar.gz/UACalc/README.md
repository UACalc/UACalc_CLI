This is the repo from which we create UACalc.tar, which will be posted at http://uacalc.org.
When UACalc.tar is downloaded and untarred, it will create the following directories:

    ~/UACalc/Algebras
    ~/UACalc/Examples
    ~/UACalc/UACalc_CLI

